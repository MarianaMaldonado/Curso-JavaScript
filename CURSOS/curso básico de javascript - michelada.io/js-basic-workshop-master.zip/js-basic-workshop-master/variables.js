const hola = 3;
console.log(hola)