const numerito = 374;
const punto = 9.6;

const fakeNumber = '9.6';

console.log(numerito);
console.log(punto);
console.log(fakeNumber);
console.log(9 + 9);
console.log(9 - 9);
console.log(9 * 9);
console.log(9 / 9);
console.log(9 + fakeNumber); // no lo haga
console.log(fakeNumber + 9); // tampoco

console.log(1 / 0);
console.log(Infinity);
console.log('hahah' / 1);
