// hahahl;jdlkjdljkkdfgjdgjklhgdfj;

/*
  hola
  lkjd
  gfd
  gfd
  gf
*/

// let age = 17;

// if (age >= 18) {
//   alert('Yay, puedes entrar');
// } else {
//   alert(':(, no puedes entrar, sorry');
// }

// let areYouSure =
//  confirm('Estás seguro de querer borrarlo');

// if (areYouSure ===  true) {
//   alert('ya lo borré, ni modín pinguín');
// } else {
//   alert('yay, no lo borré, todo va a estar bien');
// }

// si tienes menos de quince años igual a infante
// si tienes quince y 21 entonces es un adulto joven
// si tiene entre 21 y 50 es un adulto
// los demas son viejitos

let otraEdad = 99;

//condiciones para saber en que parte de su vida está
if (otraEdad < 15) {
  alert('eres un infante')
} else if (otraEdad <= 21) {
  alert('eres un adulto joven');
} else if (otraEdad <= 50) {
  alert('eres un adulto');
} else {
  alert('ya estas robando aire, viejito');
}