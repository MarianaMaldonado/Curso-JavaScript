console.log('Hola, amiwos');

// alert('Hola, te aprecio');

const name = 'Alexis';
const age = 22;

// alert(age);
// alert('Ups, algo salió mal')

let seEstanDivirtiendo =
 confirm('Deseas continuar y borrar ese post?');

seEstanDivirtiendo = true;

