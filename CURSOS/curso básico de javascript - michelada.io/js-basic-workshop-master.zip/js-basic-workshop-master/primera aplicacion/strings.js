const string = 'HOLA';
const anotherString = "Hola";
const concatString = `Hola`;

let hola = "I'm tall";

const hello = "Hello,";
const world = "mundito";

console.log(hello + ' ' + world);
console.log(`${hello} ${world}`);
console.log('${hello} ${world}'); //esto no sirve :(