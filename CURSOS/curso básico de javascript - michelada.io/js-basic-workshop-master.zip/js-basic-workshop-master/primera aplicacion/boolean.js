const isTrue = true;
const isFalse = false;

const anotherBoolean = 9 > 10;
console.log(anotherBoolean);
console.log( 9 < 10);
console.log(11 <= 10);
console.log(11 >= 10);
console.log(10 == 10);
console.log('10' == 10);
console.log(10 === 10);
console.log('10' === 10);

// null :o
const empty = null;
console.log(empty);

// undefined
let j;
console.log(j);
console.log(noExisto)