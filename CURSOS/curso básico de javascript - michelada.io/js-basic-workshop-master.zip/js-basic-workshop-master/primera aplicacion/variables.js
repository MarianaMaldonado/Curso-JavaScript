const amor = 'Ella no te ama';

let age = 22;
age = 23;
age = 'tengo 23 años';
age = 98;

age = amor;

var hola = 'hola';
hola = 'adiós';

let camelCase = 3;
let snake_case = 4;

let problems99 = ':(';

const HOLA_MUNDO = 'HOLA';